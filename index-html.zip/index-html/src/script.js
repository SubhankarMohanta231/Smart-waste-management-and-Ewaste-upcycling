document.addEventListener("DOMContentLoaded", () => {
  // Handle form submissions here

  const donationForm = document.querySelector("#donation form");

  donationForm.addEventListener("submit", function (e) {
    e.preventDefault();

    alert("Thank you for your donation! We will contact you for pickup soon.");
  });

  const contactForm = document.querySelector("#contact form");

  contactForm.addEventListener("submit", function (e) {
    e.preventDefault();

    alert("Thank you for contacting us. We will get back to you shortly.");
  });
});
